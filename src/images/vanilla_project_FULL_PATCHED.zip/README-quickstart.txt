Quick Start

1) Open index.html in your browser to navigate all pages.
2) If you use VS Code, install Live Server and click "Go Live" from the status bar.
3) Folder structure kept as in your upload. You can reorganize later and update links.

Paths detected:
- HTML pages:
  - __MACOSX/untitled folder/contact/._contact.html
  - __MACOSX/untitled folder/final iti/Html/._code.html
  - __MACOSX/untitled folder/hanoura/project_iti/._vehicles.html
  - __MACOSX/untitled folder/hanoura/project_iti/components/._footer.html
  - __MACOSX/untitled folder/hanoura/project_iti/components/._header.html
  - __MACOSX/untitled folder/hanoura/project_iti/components/._vehicle-card.html
  - __MACOSX/untitled folder/shehab/._about.html
  - __MACOSX/untitled folder/shehab/._home.html
  - __MACOSX/untitled folder/shehab/._login.html
  - __MACOSX/untitled folder/shehab/._signup.html
  - index.html
  - untitled folder/contact/contact.html
  - untitled folder/final iti/Html/code.html
  - untitled folder/hanoura/project_iti/components/footer.html
  - untitled folder/hanoura/project_iti/components/header.html
  - untitled folder/hanoura/project_iti/components/vehicle-card.html
  - untitled folder/hanoura/project_iti/vehicles.html
  - untitled folder/shehab/about.html
  - untitled folder/shehab/home.html
  - untitled folder/shehab/login.html
  - untitled folder/shehab/signup.html

- CSS files:
  - untitled folder/contact/dist/output.css
  - untitled folder/contact/src/css/contact.css
  - untitled folder/contact/src/css/input.css
  - untitled folder/hanoura/project_iti/css/style.css
  - untitled folder/final iti/css/style.css
  - untitled folder/shehab/style.css
  - __MACOSX/untitled folder/contact/dist/._output.css
  - __MACOSX/untitled folder/contact/src/css/._contact.css
  - __MACOSX/untitled folder/contact/src/css/._input.css
  - __MACOSX/untitled folder/hanoura/project_iti/css/._style.css
  - __MACOSX/untitled folder/final iti/css/._style.css
  - __MACOSX/untitled folder/shehab/._style.css

- JS files:
  - untitled folder/contact/src/js/contact.js
  - untitled folder/hanoura/project_iti/js/script.js
  - untitled folder/hanoura/project_iti/js/data.js
  - untitled folder/final iti/java script/script.js
  - __MACOSX/untitled folder/contact/src/js/._contact.js
  - __MACOSX/untitled folder/hanoura/project_iti/js/._script.js
  - __MACOSX/untitled folder/hanoura/project_iti/js/._data.js
  - __MACOSX/untitled folder/final iti/java script/._script.js
